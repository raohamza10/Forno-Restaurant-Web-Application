import { useState, useEffect, useContext, createContext, useRef } from "react";

// ─── CONTEXT ────────────────────────────────────────────────────────────────
const AppContext = createContext();

// ─── DATA ───────────────────────────────────────────────────────────────────
const MENU = [
  { id: 1, name: "Margherita Pizza", category: "Pizza", price: 14.99, rating: 4.8, veg: true, img: "🍕", desc: "Classic tomato sauce, fresh mozzarella & basil", badge: "Chef's Pick" },
  { id: 2, name: "BBQ Chicken Pizza", category: "Pizza", price: 17.99, rating: 4.7, veg: false, img: "🍕", desc: "Smoky BBQ sauce, grilled chicken & red onion", badge: "" },
  { id: 3, name: "Pepperoni Feast", category: "Pizza", price: 16.99, rating: 4.9, veg: false, img: "🍕", desc: "Double pepperoni, mozzarella & oregano", badge: "Bestseller" },
  { id: 4, name: "Truffle Mushroom Pizza", category: "Pizza", price: 19.99, rating: 4.6, veg: true, img: "🍕", desc: "White truffle oil, porcini, arugula", badge: "" },
  { id: 5, name: "Classic Cheeseburger", category: "Burgers", price: 11.99, rating: 4.7, veg: false, img: "🍔", desc: "Wagyu beef, aged cheddar, house pickles", badge: "Bestseller" },
  { id: 6, name: "Mushroom Swiss Burger", category: "Burgers", price: 13.99, rating: 4.5, veg: true, img: "🍔", desc: "Portobello patty, Swiss cheese, garlic aioli", badge: "" },
  { id: 7, name: "Spicy Jalapeño Burger", category: "Burgers", price: 12.99, rating: 4.6, veg: false, img: "🍔", desc: "Angus beef, pepper jack, pickled jalapeños", badge: "🔥 Spicy" },
  { id: 8, name: "BBQ Bacon Stack", category: "Burgers", price: 15.99, rating: 4.8, veg: false, img: "🍔", desc: "Double patty, crispy bacon, onion rings", badge: "" },
  { id: 9, name: "Mango Lassi", category: "Drinks", price: 4.99, rating: 4.9, veg: true, img: "🥭", desc: "Fresh mango, yogurt & cardamom", badge: "Popular" },
  { id: 10, name: "Lemonade Fizz", category: "Drinks", price: 3.99, rating: 4.5, veg: true, img: "🍋", desc: "Freshly squeezed lemons, mint, sparkling water", badge: "" },
  { id: 11, name: "Cold Brew Coffee", category: "Drinks", price: 5.99, rating: 4.7, veg: true, img: "☕", desc: "18-hr cold-steeped, served over ice", badge: "" },
  { id: 12, name: "Berry Smoothie", category: "Drinks", price: 5.49, rating: 4.6, veg: true, img: "🫐", desc: "Blueberry, strawberry, banana & oat milk", badge: "" },
  { id: 13, name: "Garlic Bread", category: "Sides", price: 4.99, rating: 4.4, veg: true, img: "🥖", desc: "Toasted sourdough, garlic butter, herbs", badge: "" },
  { id: 14, name: "Loaded Fries", category: "Sides", price: 6.99, rating: 4.8, veg: true, img: "🍟", desc: "Crispy fries, cheese sauce, jalapeños, sour cream", badge: "Bestseller" },
  { id: 15, name: "Onion Rings", category: "Sides", price: 5.49, rating: 4.3, veg: true, img: "🧅", desc: "Beer-battered, golden, with chipotle dip", badge: "" },
  { id: 16, name: "Chocolate Lava Cake", category: "Desserts", price: 7.99, rating: 4.9, veg: true, img: "🍫", desc: "Warm dark chocolate cake, vanilla ice cream", badge: "Chef's Pick" },
  { id: 17, name: "Mango Sorbet", category: "Desserts", price: 5.99, rating: 4.7, veg: true, img: "🍨", desc: "Alphonso mango, lime zest, fresh mint", badge: "" },
  { id: 18, name: "Tiramisu", category: "Desserts", price: 6.99, rating: 4.8, veg: true, img: "🍰", desc: "Espresso-soaked ladyfingers, mascarpone cream", badge: "" },
];

const REVIEWS = [
  { id: 1, name: "Aria M.", rating: 5, text: "Absolutely outstanding! The truffle pizza changed my life. Ambience is incredible.", avatar: "AM", date: "Apr 2026" },
  { id: 2, name: "James K.", rating: 5, text: "Best burgers in the city. The loaded fries are addictive. Will definitely be back!", avatar: "JK", date: "Apr 2026" },
  { id: 3, name: "Priya S.", rating: 4, text: "Lovely place, great food. The mango lassi is a must-try. Slightly long wait time.", avatar: "PS", date: "Mar 2026" },
  { id: 4, name: "Carlos R.", rating: 5, text: "Perfect date night spot. Everything tasted fresh, and the staff was incredibly warm.", avatar: "CR", date: "Mar 2026" },
];

const CATEGORIES = ["All", "Pizza", "Burgers", "Drinks", "Sides", "Desserts"];

// ─── TOAST ──────────────────────────────────────────────────────────────────
function Toast({ toasts }) {
  return (
    <div className="fixed bottom-6 right-6 z-[9999] flex flex-col gap-2 pointer-events-none">
      {toasts.map(t => (
        <div key={t.id} className="bg-gray-900 dark:bg-white text-white dark:text-gray-900 px-4 py-3 rounded-2xl shadow-2xl text-sm font-medium flex items-center gap-2 animate-bounce-in">
          <span className="text-base">{t.icon}</span> {t.msg}
        </div>
      ))}
    </div>
  );
}

// ─── NAVBAR ─────────────────────────────────────────────────────────────────
function Navbar({ page, setPage, dark, setDark, cartCount, wishCount }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const links = ["Home", "Menu", "About", "Contact"];
  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${dark ? "bg-gray-950/95" : "bg-white/95"} backdrop-blur border-b ${dark ? "border-gray-800" : "border-gray-100"}`}>
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <button onClick={() => setPage("Home")} className="flex items-center gap-2 font-black text-xl tracking-tight" style={{ fontFamily: "'Playfair Display', serif" }}>
          <span className="text-2xl">🍽️</span>
          <span className={dark ? "text-white" : "text-gray-900"}>Forno<span className="text-orange-500">.</span></span>
        </button>
        <div className="hidden md:flex items-center gap-1">
          {links.map(l => (
            <button key={l} onClick={() => setPage(l)} className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${page === l ? "bg-orange-500 text-white" : dark ? "text-gray-300 hover:text-white hover:bg-gray-800" : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"}`}>{l}</button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setDark(!dark)} className={`p-2 rounded-xl transition-all ${dark ? "bg-gray-800 text-yellow-400 hover:bg-gray-700" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>
            {dark ? "☀️" : "🌙"}
          </button>
          <button onClick={() => setPage("Wishlist")} className="relative p-2 rounded-xl transition-all bg-pink-50 dark:bg-pink-900/20 text-pink-500 hover:bg-pink-100">
            ❤️
            {wishCount > 0 && <span className="absolute -top-1 -right-1 w-4 h-4 bg-pink-500 text-white text-xs rounded-full flex items-center justify-center">{wishCount}</span>}
          </button>
          <button onClick={() => setPage("Cart")} className={`relative flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${dark ? "bg-orange-500 hover:bg-orange-400" : "bg-orange-500 hover:bg-orange-600"} text-white`}>
            🛒 Cart
            {cartCount > 0 && <span className="w-5 h-5 bg-white text-orange-500 text-xs rounded-full flex items-center justify-center font-bold">{cartCount}</span>}
          </button>
          <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden p-2 rounded-xl">☰</button>
        </div>
      </div>
      {mobileOpen && (
        <div className={`md:hidden px-4 pb-4 flex flex-col gap-1 ${dark ? "bg-gray-950" : "bg-white"}`}>
          {links.map(l => (
            <button key={l} onClick={() => { setPage(l); setMobileOpen(false); }} className={`px-4 py-3 rounded-xl text-sm font-medium text-left transition-all ${page === l ? "bg-orange-500 text-white" : dark ? "text-gray-300" : "text-gray-700"}`}>{l}</button>
          ))}
        </div>
      )}
    </nav>
  );
}

// ─── HOME PAGE ───────────────────────────────────────────────────────────────
function HomePage({ setPage, dark, menu, wishlist, toggleWish, addToCart }) {
  const featured = menu.filter(i => i.badge === "Bestseller" || i.badge === "Chef's Pick").slice(0, 4);
  return (
    <div>
      {/* Hero */}
      <section className={`relative min-h-screen flex items-center overflow-hidden ${dark ? "bg-gray-950" : "bg-amber-50"}`}>
        <div className="absolute inset-0 overflow-hidden">
          <div className={`absolute top-20 right-0 w-[600px] h-[600px] rounded-full opacity-20 blur-3xl ${dark ? "bg-orange-500" : "bg-orange-300"}`} />
          <div className={`absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full opacity-10 blur-3xl ${dark ? "bg-yellow-500" : "bg-yellow-400"}`} />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 py-32 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <span className={`inline-block px-4 py-2 rounded-full text-sm font-semibold mb-6 ${dark ? "bg-orange-500/20 text-orange-400" : "bg-orange-100 text-orange-600"}`}>✨ Award-Winning Restaurant</span>
            <h1 className={`font-black leading-tight mb-6 ${dark ? "text-white" : "text-gray-900"}`} style={{ fontSize: "clamp(2.5rem,6vw,4.5rem)", fontFamily: "'Playfair Display', serif" }}>
              Where Every Bite Tells a <span className="text-orange-500">Story</span>
            </h1>
            <p className={`text-lg mb-8 leading-relaxed ${dark ? "text-gray-400" : "text-gray-600"}`}>
              Crafted with passion, served with love. Discover an extraordinary dining experience where tradition meets innovation.
            </p>
            <div className="flex flex-wrap gap-4">
              <button onClick={() => setPage("Menu")} className="px-8 py-4 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-2xl transition-all transform hover:scale-105 shadow-lg shadow-orange-500/30">
                🍽️ Order Now
              </button>
              <button onClick={() => setPage("Menu")} className={`px-8 py-4 font-bold rounded-2xl transition-all border-2 ${dark ? "border-gray-700 text-gray-300 hover:border-orange-500 hover:text-orange-400" : "border-gray-300 text-gray-700 hover:border-orange-500 hover:text-orange-500"}`}>
                📜 View Menu
              </button>
            </div>
            <div className="flex items-center gap-8 mt-10">
              {[["4.9★", "Rating"], ["200+", "Dishes"], ["50K+", "Happy Guests"]].map(([n, l]) => (
                <div key={l}>
                  <div className={`text-2xl font-black ${dark ? "text-white" : "text-gray-900"}`}>{n}</div>
                  <div className={`text-sm ${dark ? "text-gray-500" : "text-gray-500"}`}>{l}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="relative flex justify-center">
            <div className={`w-72 h-72 md:w-96 md:h-96 rounded-full flex items-center justify-center text-9xl shadow-2xl ${dark ? "bg-gray-800" : "bg-white"}`} style={{ boxShadow: "0 30px 80px rgba(249,115,22,0.25)" }}>
              🍕
            </div>
            <div className={`absolute top-8 -right-4 px-4 py-2 rounded-2xl shadow-lg text-sm font-semibold animate-pulse ${dark ? "bg-gray-800 text-white" : "bg-white text-gray-900"}`}>⚡ 30-min delivery</div>
            <div className={`absolute bottom-8 -left-4 px-4 py-2 rounded-2xl shadow-lg text-sm font-semibold ${dark ? "bg-gray-800 text-white" : "bg-white text-gray-900"}`}>🌿 Fresh ingredients</div>
          </div>
        </div>
      </section>

      {/* Featured */}
      <section className={`py-24 ${dark ? "bg-gray-900" : "bg-white"}`}>
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className={`inline-block px-4 py-2 rounded-full text-sm font-semibold mb-4 ${dark ? "bg-orange-500/20 text-orange-400" : "bg-orange-100 text-orange-600"}`}>⭐ Fan Favourites</span>
            <h2 className={`font-black text-4xl ${dark ? "text-white" : "text-gray-900"}`} style={{ fontFamily: "'Playfair Display', serif" }}>Most Loved Dishes</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featured.map(item => (
              <FoodCard key={item.id} item={item} dark={dark} wished={wishlist.includes(item.id)} onWish={() => toggleWish(item.id)} onAdd={() => addToCart(item)} />
            ))}
          </div>
          <div className="text-center mt-12">
            <button onClick={() => setPage("Menu")} className="px-8 py-4 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-2xl transition-all transform hover:scale-105">
              See Full Menu →
            </button>
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className={`py-24 ${dark ? "bg-gray-950" : "bg-amber-50"}`}>
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className={`font-black text-4xl mb-4 ${dark ? "text-white" : "text-gray-900"}`} style={{ fontFamily: "'Playfair Display', serif" }}>What Guests Say</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {REVIEWS.map(r => (
              <div key={r.id} className={`p-6 rounded-3xl ${dark ? "bg-gray-900" : "bg-white"} shadow-sm`}>
                <div className="flex text-yellow-400 mb-3 text-lg">{"★".repeat(r.rating)}</div>
                <p className={`text-sm leading-relaxed mb-4 ${dark ? "text-gray-300" : "text-gray-600"}`}>"{r.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-orange-500 flex items-center justify-center text-white text-xs font-bold">{r.avatar}</div>
                  <div>
                    <div className={`text-sm font-semibold ${dark ? "text-white" : "text-gray-900"}`}>{r.name}</div>
                    <div className="text-xs text-gray-400">{r.date}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Order Tracking Dummy */}
      <section className={`py-24 ${dark ? "bg-gray-900" : "bg-white"}`}>
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className={`font-black text-3xl mb-4 ${dark ? "text-white" : "text-gray-900"}`} style={{ fontFamily: "'Playfair Display', serif" }}>Live Order Tracking</h2>
          <p className={`mb-12 ${dark ? "text-gray-400" : "text-gray-600"}`}>Always know where your food is</p>
          <OrderTracker dark={dark} />
        </div>
      </section>
    </div>
  );
}

function OrderTracker({ dark }) {
  const [step, setStep] = useState(1);
  const steps = [
    { icon: "👨‍🍳", label: "Preparing", desc: "Chef is crafting your meal" },
    { icon: "📦", label: "Packing", desc: "Being carefully packed" },
    { icon: "🛵", label: "On the Way", desc: "Out for delivery" },
    { icon: "✅", label: "Delivered", desc: "Enjoy your meal!" },
  ];
  useEffect(() => {
    const iv = setInterval(() => setStep(s => s < 4 ? s + 1 : 1), 2000);
    return () => clearInterval(iv);
  }, []);
  return (
    <div className={`p-8 rounded-3xl ${dark ? "bg-gray-800" : "bg-orange-50"}`}>
      <div className="flex justify-between items-center relative">
        <div className="absolute top-6 left-0 right-0 h-1 bg-gray-200 dark:bg-gray-700 z-0">
          <div className="h-full bg-orange-500 transition-all duration-700 rounded-full" style={{ width: `${((step - 1) / 3) * 100}%` }} />
        </div>
        {steps.map((s, i) => (
          <div key={i} className="relative z-10 flex flex-col items-center gap-2 flex-1">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center text-xl transition-all duration-300 ${i < step ? "bg-orange-500 shadow-lg shadow-orange-500/30 scale-110" : dark ? "bg-gray-700" : "bg-white border-2 border-gray-200"}`}>{s.icon}</div>
            <div className={`text-xs font-semibold hidden sm:block ${i < step ? "text-orange-500" : dark ? "text-gray-500" : "text-gray-400"}`}>{s.label}</div>
          </div>
        ))}
      </div>
      <p className={`mt-6 text-sm font-medium ${dark ? "text-gray-300" : "text-gray-600"}`}>{steps[step - 1].desc}</p>
    </div>
  );
}

// ─── FOOD CARD ───────────────────────────────────────────────────────────────
function FoodCard({ item, dark, wished, onWish, onAdd }) {
  return (
    <div className={`group rounded-3xl overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-xl ${dark ? "bg-gray-800 hover:shadow-orange-500/10" : "bg-white shadow-sm hover:shadow-orange-500/10"} border ${dark ? "border-gray-700" : "border-gray-100"}`}>
      <div className={`relative h-44 flex items-center justify-center text-7xl ${dark ? "bg-gray-700" : "bg-amber-50"}`}>
        {item.img}
        {item.badge && <span className="absolute top-3 left-3 px-2 py-1 bg-orange-500 text-white text-xs font-bold rounded-lg">{item.badge}</span>}
        <button onClick={onWish} className={`absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center text-sm transition-all ${wished ? "bg-pink-500 text-white" : dark ? "bg-gray-600 text-gray-300 hover:bg-pink-500 hover:text-white" : "bg-white text-gray-400 hover:bg-pink-50 hover:text-pink-500"}`}>
          {wished ? "❤️" : "🤍"}
        </button>
        {item.veg && <span className="absolute bottom-3 right-3 w-5 h-5 border-2 border-green-500 flex items-center justify-center rounded bg-white text-green-500 text-xs font-black">V</span>}
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-1">
          <h3 className={`font-bold text-sm leading-tight ${dark ? "text-white" : "text-gray-900"}`}>{item.name}</h3>
          <div className="flex items-center gap-1 text-xs text-yellow-500 whitespace-nowrap">⭐ {item.rating}</div>
        </div>
        <p className={`text-xs mb-3 leading-relaxed ${dark ? "text-gray-400" : "text-gray-500"}`}>{item.desc}</p>
        <div className="flex items-center justify-between">
          <span className="font-black text-orange-500 text-lg">${item.price.toFixed(2)}</span>
          <button onClick={onAdd} className="flex items-center gap-1 px-3 py-2 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold rounded-xl transition-all active:scale-95">
            + Add
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── MENU PAGE ───────────────────────────────────────────────────────────────
function MenuPage({ dark, menu, wishlist, toggleWish, addToCart }) {
  const [cat, setCat] = useState("All");
  const [search, setSearch] = useState("");
  const [vegFilter, setVegFilter] = useState("all");
  const [maxPrice, setMaxPrice] = useState(25);
  const [sortBy, setSortBy] = useState("default");

  let items = menu.filter(i =>
    (cat === "All" || i.category === cat) &&
    (vegFilter === "all" || (vegFilter === "veg" ? i.veg : !i.veg)) &&
    i.price <= maxPrice &&
    (search === "" || i.name.toLowerCase().includes(search.toLowerCase()) || i.desc.toLowerCase().includes(search.toLowerCase()))
  );
  if (sortBy === "priceLow") items = [...items].sort((a, b) => a.price - b.price);
  if (sortBy === "priceHigh") items = [...items].sort((a, b) => b.price - a.price);
  if (sortBy === "rating") items = [...items].sort((a, b) => b.rating - a.rating);

  return (
    <div className={`min-h-screen pt-20 ${dark ? "bg-gray-950" : "bg-gray-50"}`}>
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className={`font-black text-5xl mb-4 ${dark ? "text-white" : "text-gray-900"}`} style={{ fontFamily: "'Playfair Display', serif" }}>Our Menu</h1>
          <p className={dark ? "text-gray-400" : "text-gray-600"}>Every dish crafted with love & the finest ingredients</p>
        </div>

        {/* Controls */}
        <div className={`sticky top-16 z-30 py-4 mb-8 ${dark ? "bg-gray-950" : "bg-gray-50"}`}>
          <div className="flex flex-col gap-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">🔍</span>
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search dishes..."
                  className={`w-full pl-11 pr-4 py-3 rounded-2xl border outline-none text-sm ${dark ? "bg-gray-800 border-gray-700 text-white placeholder-gray-500 focus:border-orange-500" : "bg-white border-gray-200 text-gray-900 focus:border-orange-400"}`} />
              </div>
              <select value={sortBy} onChange={e => setSortBy(e.target.value)} className={`px-4 py-3 rounded-2xl border text-sm outline-none ${dark ? "bg-gray-800 border-gray-700 text-white" : "bg-white border-gray-200 text-gray-900"}`}>
                <option value="default">Sort: Default</option>
                <option value="priceLow">Price: Low to High</option>
                <option value="priceHigh">Price: High to Low</option>
                <option value="rating">Top Rated</option>
              </select>
            </div>
            <div className="flex flex-wrap gap-2 items-center">
              {CATEGORIES.map(c => (
                <button key={c} onClick={() => setCat(c)} className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${cat === c ? "bg-orange-500 text-white shadow-lg shadow-orange-500/30" : dark ? "bg-gray-800 text-gray-300 hover:bg-gray-700" : "bg-white text-gray-600 hover:bg-orange-50"}`}>{c}</button>
              ))}
              <div className="ml-auto flex items-center gap-2">
                {["all", "veg", "nonveg"].map(v => (
                  <button key={v} onClick={() => setVegFilter(v)} className={`px-3 py-2 rounded-xl text-xs font-bold transition-all ${vegFilter === v ? (v === "veg" ? "bg-green-500 text-white" : v === "nonveg" ? "bg-red-500 text-white" : "bg-gray-500 text-white") : dark ? "bg-gray-800 text-gray-400" : "bg-white text-gray-500"}`}>
                    {v === "all" ? "All" : v === "veg" ? "🟢 Veg" : "🔴 Non-Veg"}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className={`text-sm whitespace-nowrap ${dark ? "text-gray-400" : "text-gray-600"}`}>Max Price: <strong className="text-orange-500">${maxPrice}</strong></span>
              <input type="range" min={3} max={25} value={maxPrice} onChange={e => setMaxPrice(+e.target.value)} className="flex-1 accent-orange-500" />
            </div>
          </div>
        </div>

        {items.length === 0 ? (
          <div className="text-center py-24">
            <div className="text-6xl mb-4">🍽️</div>
            <p className={`text-lg ${dark ? "text-gray-400" : "text-gray-500"}`}>No dishes found. Try different filters!</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {items.map(item => (
              <FoodCard key={item.id} item={item} dark={dark} wished={wishlist.includes(item.id)} onWish={() => toggleWish(item.id)} onAdd={() => addToCart(item)} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── CART PAGE ───────────────────────────────────────────────────────────────
function CartPage({ dark, cart, updateQty, removeItem, clearCart, setPage }) {
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const tax = total * 0.08;
  const delivery = total > 0 ? 2.99 : 0;

  if (cart.length === 0) return (
    <div className={`min-h-screen flex flex-col items-center justify-center pt-20 ${dark ? "bg-gray-950 text-white" : "bg-gray-50 text-gray-900"}`}>
      <div className="text-8xl mb-6">🛒</div>
      <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
      <p className={`mb-8 ${dark ? "text-gray-400" : "text-gray-500"}`}>Add some delicious food to get started!</p>
      <button onClick={() => setPage("Menu")} className="px-8 py-4 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-2xl transition-all">Browse Menu</button>
    </div>
  );

  return (
    <div className={`min-h-screen pt-20 ${dark ? "bg-gray-950" : "bg-gray-50"}`}>
      <div className="max-w-5xl mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-8">
          <h1 className={`font-black text-4xl ${dark ? "text-white" : "text-gray-900"}`} style={{ fontFamily: "'Playfair Display', serif" }}>Your Cart</h1>
          <button onClick={clearCart} className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${dark ? "bg-red-900/30 text-red-400 hover:bg-red-900/50" : "bg-red-50 text-red-500 hover:bg-red-100"}`}>🗑️ Clear All</button>
        </div>
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 flex flex-col gap-4">
            {cart.map(item => (
              <div key={item.id} className={`p-5 rounded-3xl flex items-center gap-4 ${dark ? "bg-gray-800" : "bg-white"} shadow-sm`}>
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-4xl flex-shrink-0 ${dark ? "bg-gray-700" : "bg-amber-50"}`}>{item.img}</div>
                <div className="flex-1 min-w-0">
                  <h3 className={`font-bold truncate ${dark ? "text-white" : "text-gray-900"}`}>{item.name}</h3>
                  <p className="text-orange-500 font-semibold">${item.price.toFixed(2)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => updateQty(item.id, -1)} className={`w-8 h-8 rounded-full font-bold text-lg flex items-center justify-center transition-all ${dark ? "bg-gray-700 text-white hover:bg-gray-600" : "bg-gray-100 hover:bg-gray-200"}`}>−</button>
                  <span className={`w-8 text-center font-bold ${dark ? "text-white" : "text-gray-900"}`}>{item.qty}</span>
                  <button onClick={() => updateQty(item.id, 1)} className="w-8 h-8 rounded-full bg-orange-500 text-white font-bold text-lg flex items-center justify-center hover:bg-orange-600 transition-all">+</button>
                </div>
                <div className="text-right">
                  <p className={`font-black ${dark ? "text-white" : "text-gray-900"}`}>${(item.price * item.qty).toFixed(2)}</p>
                  <button onClick={() => removeItem(item.id)} className="text-xs text-red-400 hover:text-red-500 mt-1">Remove</button>
                </div>
              </div>
            ))}
          </div>
          <div>
            <div className={`p-6 rounded-3xl sticky top-24 ${dark ? "bg-gray-800" : "bg-white"} shadow-sm`}>
              <h2 className={`font-bold text-xl mb-6 ${dark ? "text-white" : "text-gray-900"}`}>Order Summary</h2>
              <div className={`space-y-3 text-sm ${dark ? "text-gray-300" : "text-gray-600"}`}>
                <div className="flex justify-between"><span>Subtotal</span><span>${total.toFixed(2)}</span></div>
                <div className="flex justify-between"><span>Tax (8%)</span><span>${tax.toFixed(2)}</span></div>
                <div className="flex justify-between"><span>Delivery</span><span>${delivery.toFixed(2)}</span></div>
                <div className={`flex justify-between font-black text-lg pt-3 border-t ${dark ? "border-gray-700 text-white" : "border-gray-200 text-gray-900"}`}>
                  <span>Total</span><span className="text-orange-500">${(total + tax + delivery).toFixed(2)}</span>
                </div>
              </div>
              <div className="mt-6 flex gap-2">
                <input placeholder="Coupon code" className={`flex-1 px-3 py-2 rounded-xl border text-sm outline-none ${dark ? "bg-gray-700 border-gray-600 text-white placeholder-gray-500" : "border-gray-200"}`} />
                <button className="px-3 py-2 bg-orange-100 text-orange-600 rounded-xl text-sm font-semibold hover:bg-orange-200">Apply</button>
              </div>
              <button onClick={() => setPage("Checkout")} className="w-full mt-4 py-4 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-2xl transition-all transform hover:scale-105 shadow-lg shadow-orange-500/30">
                Proceed to Checkout →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── CHECKOUT PAGE ────────────────────────────────────────────────────────────
function CheckoutPage({ dark, cart, clearCart, setPage, addToast }) {
  const [form, setForm] = useState({ name: "", email: "", phone: "", address: "", city: "", zip: "" });
  const [errors, setErrors] = useState({});
  const [placed, setPlaced] = useState(false);
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Name required";
    if (!form.email.match(/\S+@\S+\.\S+/)) e.email = "Valid email required";
    if (!form.phone.match(/^\+?[\d\s\-]{8,}/)) e.phone = "Valid phone required";
    if (!form.address.trim()) e.address = "Address required";
    if (!form.city.trim()) e.city = "City required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    setPlaced(true);
    clearCart();
    addToast("🎉", "Order placed successfully!");
  };

  if (placed) return (
    <div className={`min-h-screen flex flex-col items-center justify-center pt-20 px-4 ${dark ? "bg-gray-950 text-white" : "bg-gray-50 text-gray-900"}`}>
      <div className="text-8xl mb-6 animate-bounce">🎉</div>
      <h2 className="text-3xl font-black mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>Order Placed!</h2>
      <p className={`mb-2 ${dark ? "text-gray-400" : "text-gray-600"}`}>Thank you, {form.name || "Friend"}!</p>
      <p className={`mb-8 text-sm ${dark ? "text-gray-500" : "text-gray-500"}`}>Your food is being prepared. Estimated: 30 minutes.</p>
      <OrderTracker dark={dark} />
      <button onClick={() => setPage("Home")} className="mt-8 px-8 py-4 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-2xl transition-all">Back to Home</button>
    </div>
  );

  return (
    <div className={`min-h-screen pt-20 ${dark ? "bg-gray-950" : "bg-gray-50"}`}>
      <div className="max-w-5xl mx-auto px-4 py-12">
        <h1 className={`font-black text-4xl mb-8 ${dark ? "text-white" : "text-gray-900"}`} style={{ fontFamily: "'Playfair Display', serif" }}>Checkout</h1>
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className={`p-6 rounded-3xl mb-6 ${dark ? "bg-gray-800" : "bg-white"}`}>
              <h2 className={`font-bold text-xl mb-6 ${dark ? "text-white" : "text-gray-900"}`}>Delivery Details</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                {[["name", "Full Name", "text"], ["email", "Email", "email"], ["phone", "Phone Number", "tel"], ["address", "Street Address", "text"], ["city", "City", "text"], ["zip", "ZIP Code", "text"]].map(([k, l, t]) => (
                  <div key={k} className={k === "address" ? "sm:col-span-2" : ""}>
                    <label className={`text-sm font-semibold mb-1 block ${dark ? "text-gray-300" : "text-gray-700"}`}>{l}</label>
                    <input type={t} value={form[k]} onChange={e => setForm({ ...form, [k]: e.target.value })}
                      className={`w-full px-4 py-3 rounded-2xl border outline-none text-sm transition-all ${errors[k] ? "border-red-400" : dark ? "bg-gray-700 border-gray-600 text-white focus:border-orange-500" : "border-gray-200 focus:border-orange-400"}`} />
                    {errors[k] && <p className="text-red-400 text-xs mt-1">{errors[k]}</p>}
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div>
            <div className={`p-6 rounded-3xl ${dark ? "bg-gray-800" : "bg-white"}`}>
              <h2 className={`font-bold text-xl mb-4 ${dark ? "text-white" : "text-gray-900"}`}>Your Order</h2>
              <div className="space-y-3 mb-6">
                {cart.map(i => (
                  <div key={i.id} className="flex justify-between items-center gap-2">
                    <span className="text-xl">{i.img}</span>
                    <span className={`flex-1 text-sm ${dark ? "text-gray-300" : "text-gray-700"}`}>{i.name} x{i.qty}</span>
                    <span className="text-orange-500 font-semibold text-sm">${(i.price * i.qty).toFixed(2)}</span>
                  </div>
                ))}
              </div>
              <div className={`pt-4 border-t flex justify-between font-black text-lg ${dark ? "border-gray-700 text-white" : "border-gray-200 text-gray-900"}`}>
                <span>Total</span><span className="text-orange-500">${(total * 1.08 + 2.99).toFixed(2)}</span>
              </div>
              <button onClick={handleSubmit} className="w-full mt-6 py-4 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-2xl transition-all transform hover:scale-105 shadow-lg shadow-orange-500/30">
                🎉 Place Order
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── WISHLIST ────────────────────────────────────────────────────────────────
function WishlistPage({ dark, menu, wishlist, toggleWish, addToCart }) {
  const items = menu.filter(i => wishlist.includes(i.id));
  return (
    <div className={`min-h-screen pt-20 ${dark ? "bg-gray-950" : "bg-gray-50"}`}>
      <div className="max-w-7xl mx-auto px-4 py-12">
        <h1 className={`font-black text-4xl mb-8 ${dark ? "text-white" : "text-gray-900"}`} style={{ fontFamily: "'Playfair Display', serif" }}>❤️ Favourites</h1>
        {items.length === 0 ? (
          <div className="text-center py-24">
            <div className="text-8xl mb-4">🤍</div>
            <p className={`text-lg ${dark ? "text-gray-400" : "text-gray-500"}`}>No favourites yet. Heart a dish!</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {items.map(item => <FoodCard key={item.id} item={item} dark={dark} wished={true} onWish={() => toggleWish(item.id)} onAdd={() => addToCart(item)} />)}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── ABOUT PAGE ──────────────────────────────────────────────────────────────
function AboutPage({ dark }) {
  const chefs = [
    { name: "Chef Marco Rossi", role: "Head Chef", emoji: "👨‍🍳", bio: "20 years of Italian culinary mastery" },
    { name: "Chef Aiko Tanaka", role: "Pastry Chef", emoji: "👩‍🍳", bio: "Paris-trained dessert artist" },
    { name: "Chef Ravi Sharma", role: "Grill Master", emoji: "👨‍🍳", bio: "Champion of BBQ & bold flavours" },
  ];
  return (
    <div className={`min-h-screen pt-20 ${dark ? "bg-gray-950" : "bg-white"}`}>
      <div className="max-w-5xl mx-auto px-4 py-12">
        <div className="text-center mb-16">
          <h1 className={`font-black text-5xl mb-4 ${dark ? "text-white" : "text-gray-900"}`} style={{ fontFamily: "'Playfair Display', serif" }}>Our Story</h1>
          <p className={`text-lg max-w-2xl mx-auto leading-relaxed ${dark ? "text-gray-400" : "text-gray-600"}`}>
            Founded in 2010, Forno was born out of a simple belief — great food brings people together. From a small family kitchen in Naples to an internationally acclaimed restaurant, our journey has been fuelled by passion and fresh ingredients.
          </p>
        </div>
        <div className={`grid md:grid-cols-3 gap-6 mb-20 text-center`}>
          {[["🌿", "Farm Fresh", "We partner with local farms for the freshest ingredients daily"], ["🔥", "Wood Fired", "Traditional wood-fired ovens for authentic flavour"], ["❤️", "Made with Love", "Every dish is crafted with care and served with a smile"]].map(([e, t, d]) => (
            <div key={t} className={`p-8 rounded-3xl ${dark ? "bg-gray-800" : "bg-amber-50"}`}>
              <div className="text-5xl mb-4">{e}</div>
              <h3 className={`font-bold text-lg mb-2 ${dark ? "text-white" : "text-gray-900"}`}>{t}</h3>
              <p className={`text-sm ${dark ? "text-gray-400" : "text-gray-600"}`}>{d}</p>
            </div>
          ))}
        </div>
        <h2 className={`font-black text-3xl text-center mb-10 ${dark ? "text-white" : "text-gray-900"}`} style={{ fontFamily: "'Playfair Display', serif" }}>Meet Our Chefs</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {chefs.map(c => (
            <div key={c.name} className={`p-6 rounded-3xl text-center ${dark ? "bg-gray-800" : "bg-white border border-gray-100"}`}>
              <div className="text-7xl mb-4">{c.emoji}</div>
              <h3 className={`font-bold text-lg ${dark ? "text-white" : "text-gray-900"}`}>{c.name}</h3>
              <p className="text-orange-500 text-sm font-semibold mb-2">{c.role}</p>
              <p className={`text-sm ${dark ? "text-gray-400" : "text-gray-600"}`}>{c.bio}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── CONTACT PAGE ─────────────────────────────────────────────────────────────
function ContactPage({ dark, addToast }) {
  const [form, setForm] = useState({ name: "", email: "", msg: "" });
  const send = () => {
    if (!form.name || !form.email || !form.msg) return;
    addToast("📬", "Message sent! We'll reply soon.");
    setForm({ name: "", email: "", msg: "" });
  };
  return (
    <div className={`min-h-screen pt-20 ${dark ? "bg-gray-950" : "bg-gray-50"}`}>
      <div className="max-w-5xl mx-auto px-4 py-12">
        <h1 className={`font-black text-5xl mb-12 text-center ${dark ? "text-white" : "text-gray-900"}`} style={{ fontFamily: "'Playfair Display', serif" }}>Get in Touch</h1>
        <div className="grid md:grid-cols-2 gap-10">
          <div>
            <div className={`p-8 rounded-3xl mb-6 ${dark ? "bg-gray-800" : "bg-white"}`}>
              <h2 className={`font-bold text-xl mb-6 ${dark ? "text-white" : "text-gray-900"}`}>Send a Message</h2>
              <div className="flex flex-col gap-4">
                {[["name", "Your Name", "text"], ["email", "Email Address", "email"]].map(([k, l, t]) => (
                  <div key={k}>
                    <label className={`text-sm font-semibold mb-1 block ${dark ? "text-gray-300" : "text-gray-700"}`}>{l}</label>
                    <input type={t} value={form[k]} onChange={e => setForm({ ...form, [k]: e.target.value })}
                      className={`w-full px-4 py-3 rounded-2xl border outline-none text-sm ${dark ? "bg-gray-700 border-gray-600 text-white focus:border-orange-500" : "border-gray-200 focus:border-orange-400"}`} />
                  </div>
                ))}
                <div>
                  <label className={`text-sm font-semibold mb-1 block ${dark ? "text-gray-300" : "text-gray-700"}`}>Message</label>
                  <textarea rows={4} value={form.msg} onChange={e => setForm({ ...form, msg: e.target.value })}
                    className={`w-full px-4 py-3 rounded-2xl border outline-none text-sm resize-none ${dark ? "bg-gray-700 border-gray-600 text-white focus:border-orange-500" : "border-gray-200 focus:border-orange-400"}`} />
                </div>
                <button onClick={send} className="py-3 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-2xl transition-all transform hover:scale-105">Send Message 📬</button>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-6">
            {[["📍", "Find Us", "123 Forno Street, Lahore, Pakistan"], ["📞", "Call Us", "+92 300 1234567"], ["✉️", "Email Us", "hello@forno.pk"], ["🕐", "Hours", "Mon–Sun · 11 AM – 11 PM"]].map(([e, t, d]) => (
              <div key={t} className={`p-5 rounded-2xl flex items-start gap-4 ${dark ? "bg-gray-800" : "bg-white"}`}>
                <span className="text-2xl">{e}</span>
                <div>
                  <div className={`font-bold ${dark ? "text-white" : "text-gray-900"}`}>{t}</div>
                  <div className={`text-sm ${dark ? "text-gray-400" : "text-gray-600"}`}>{d}</div>
                </div>
              </div>
            ))}
            <div className="rounded-2xl overflow-hidden h-48 bg-gray-200">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d217289.11714658455!2d74.1972569!3d31.5203696!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39190483e58107d9%3A0xc23abe6ccc7e2462!2sLahore%2C+Punjab%2C+Pakistan!5e0!3m2!1sen!2s!4v1620000000000"
                width="100%" height="100%" style={{ border: 0 }} allowFullScreen loading="lazy" title="map" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── AUTH PAGES ───────────────────────────────────────────────────────────────
function AuthPage({ dark, type, setPage, addToast }) {
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [errors, setErrors] = useState({});
  const isLogin = type === "Login";
  const validate = () => {
    const e = {};
    if (!isLogin && !form.name.trim()) e.name = "Name required";
    if (!form.email.match(/\S+@\S+\.\S+/)) e.email = "Valid email required";
    if (form.password.length < 6) e.password = "Password min 6 chars";
    setErrors(e);
    return Object.keys(e).length === 0;
  };
  const submit = () => {
    if (!validate()) return;
    addToast(isLogin ? "👋" : "🎉", isLogin ? "Welcome back!" : "Account created!");
    setPage("Home");
  };
  return (
    <div className={`min-h-screen pt-20 flex items-center justify-center px-4 ${dark ? "bg-gray-950" : "bg-amber-50"}`}>
      <div className={`w-full max-w-md p-8 rounded-3xl shadow-2xl ${dark ? "bg-gray-800" : "bg-white"}`}>
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">🍽️</div>
          <h1 className={`font-black text-3xl ${dark ? "text-white" : "text-gray-900"}`} style={{ fontFamily: "'Playfair Display', serif" }}>{isLogin ? "Welcome Back" : "Join Forno"}</h1>
          <p className={`text-sm mt-1 ${dark ? "text-gray-400" : "text-gray-500"}`}>{isLogin ? "Sign in to your account" : "Create your free account"}</p>
        </div>
        <div className="flex flex-col gap-4">
          {!isLogin && (
            <div>
              <label className={`text-sm font-semibold mb-1 block ${dark ? "text-gray-300" : "text-gray-700"}`}>Full Name</label>
              <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                className={`w-full px-4 py-3 rounded-2xl border outline-none text-sm ${errors.name ? "border-red-400" : dark ? "bg-gray-700 border-gray-600 text-white focus:border-orange-500" : "border-gray-200 focus:border-orange-400"}`} />
              {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
            </div>
          )}
          {[["email", "Email", "email"], ["password", "Password", "password"]].map(([k, l, t]) => (
            <div key={k}>
              <label className={`text-sm font-semibold mb-1 block ${dark ? "text-gray-300" : "text-gray-700"}`}>{l}</label>
              <input type={t} value={form[k]} onChange={e => setForm({ ...form, [k]: e.target.value })}
                className={`w-full px-4 py-3 rounded-2xl border outline-none text-sm ${errors[k] ? "border-red-400" : dark ? "bg-gray-700 border-gray-600 text-white focus:border-orange-500" : "border-gray-200 focus:border-orange-400"}`} />
              {errors[k] && <p className="text-red-400 text-xs mt-1">{errors[k]}</p>}
            </div>
          ))}
          <button onClick={submit} className="py-4 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-2xl transition-all transform hover:scale-105 mt-2">
            {isLogin ? "Sign In →" : "Create Account →"}
          </button>
          <p className={`text-center text-sm ${dark ? "text-gray-400" : "text-gray-500"}`}>
            {isLogin ? "No account? " : "Have an account? "}
            <button onClick={() => setPage(isLogin ? "Signup" : "Login")} className="text-orange-500 font-semibold hover:underline">
              {isLogin ? "Sign Up" : "Sign In"}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── FOOTER ───────────────────────────────────────────────────────────────────
function Footer({ dark, setPage }) {
  return (
    <footer className={`py-16 px-4 mt-auto ${dark ? "bg-gray-900 border-t border-gray-800" : "bg-gray-900"} text-white`}>
      <div className="max-w-7xl mx-auto">
        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-10 mb-10">
          <div>
            <div className="font-black text-2xl mb-3" style={{ fontFamily: "'Playfair Display', serif" }}>🍽️ Forno<span className="text-orange-500">.</span></div>
            <p className="text-gray-400 text-sm leading-relaxed">Where every bite tells a story. Crafted with passion since 2010.</p>
          </div>
          {[
            ["Navigate", ["Home", "Menu", "About", "Contact"]],
            ["Account", ["Login", "Signup", "Cart", "Wishlist"]],
            ["Contact", ["+92 300 1234567", "hello@forno.pk", "123 Forno Street", "Lahore, Pakistan"]],
          ].map(([title, items]) => (
            <div key={title}>
              <h3 className="font-bold mb-4">{title}</h3>
              <ul className="space-y-2">
                {items.map(i => (
                  <li key={i}>
                    <button onClick={() => { try { setPage(i); } catch { } }} className="text-gray-400 text-sm hover:text-orange-400 transition-colors text-left">{i}</button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t border-gray-800 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-sm">© 2026 Forno Restaurant. All rights reserved.</p>
          <p className="text-gray-500 text-sm">Made with ❤️ in Lahore</p>
        </div>
      </div>
    </footer>
  );
}

// ─── APP ROOT ─────────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState("Home");
  const [dark, setDark] = useState(false);
  const [cart, setCart] = useState([]);
  const [wishlist, setWishlist] = useState([]);
  const [toasts, setToasts] = useState([]);

  const addToast = (icon, msg) => {
    const id = Date.now();
    setToasts(t => [...t, { id, icon, msg }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 3000);
  };

  const addToCart = (item) => {
    setCart(c => {
      const ex = c.find(x => x.id === item.id);
      if (ex) return c.map(x => x.id === item.id ? { ...x, qty: x.qty + 1 } : x);
      return [...c, { ...item, qty: 1 }];
    });
    addToast("🛒", `${item.name} added to cart!`);
  };

  const updateQty = (id, delta) => {
    setCart(c => c.map(x => x.id === id ? { ...x, qty: Math.max(1, x.qty + delta) } : x));
  };

  const removeItem = (id) => setCart(c => c.filter(x => x.id !== id));
  const clearCart = () => setCart([]);

  const toggleWish = (id) => {
    setWishlist(w => {
      if (w.includes(id)) { addToast("💔", "Removed from favourites"); return w.filter(x => x !== id); }
      addToast("❤️", "Added to favourites!"); return [...w, id];
    });
  };

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  return (
    <div className={dark ? "dark" : ""}>
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&display=swap" rel="stylesheet" />
      <style>{`
        @keyframes bounce-in { 0%{opacity:0;transform:translateY(20px)} 60%{transform:translateY(-4px)} 100%{opacity:1;transform:translateY(0)} }
        .animate-bounce-in { animation: bounce-in 0.35s ease forwards; }
      `}</style>

      <Navbar page={page} setPage={setPage} dark={dark} setDark={setDark} cartCount={cartCount} wishCount={wishlist.length} />

      <main>
        {page === "Home" && <HomePage setPage={setPage} dark={dark} menu={MENU} wishlist={wishlist} toggleWish={toggleWish} addToCart={addToCart} />}
        {page === "Menu" && <MenuPage dark={dark} menu={MENU} wishlist={wishlist} toggleWish={toggleWish} addToCart={addToCart} />}
        {page === "Cart" && <CartPage dark={dark} cart={cart} updateQty={updateQty} removeItem={removeItem} clearCart={clearCart} setPage={setPage} />}
        {page === "Checkout" && <CheckoutPage dark={dark} cart={cart} clearCart={clearCart} setPage={setPage} addToast={addToast} />}
        {page === "Wishlist" && <WishlistPage dark={dark} menu={MENU} wishlist={wishlist} toggleWish={toggleWish} addToCart={addToCart} />}
        {page === "About" && <AboutPage dark={dark} />}
        {page === "Contact" && <ContactPage dark={dark} addToast={addToast} />}
        {page === "Login" && <AuthPage dark={dark} type="Login" setPage={setPage} addToast={addToast} />}
        {page === "Signup" && <AuthPage dark={dark} type="Signup" setPage={setPage} addToast={addToast} />}
      </main>

      <Footer dark={dark} setPage={setPage} />
      <Toast toasts={toasts} />
    </div>
  );
}
